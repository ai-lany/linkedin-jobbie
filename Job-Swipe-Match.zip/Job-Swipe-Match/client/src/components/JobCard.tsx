import { forwardRef } from "react";
import { motion, useMotionValue, useTransform, PanInfo } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Building2, MapPin, Clock, DollarSign, Briefcase, CheckCircle2 } from "lucide-react";
import type { Job } from "@shared/schema";

interface JobCardProps {
  job: Job;
  onSwipe: (direction: "left" | "right") => void;
  isTop: boolean;
}

export const JobCard = forwardRef<HTMLDivElement, JobCardProps>(
  function JobCard({ job, onSwipe, isTop }, ref) {
    const x = useMotionValue(0);
    const rotate = useTransform(x, [-300, 300], [-25, 25]);
    const opacity = useTransform(x, [-300, -100, 0, 100, 300], [0.5, 1, 1, 1, 0.5]);
    
    const likeOpacity = useTransform(x, [0, 100], [0, 1]);
    const nopeOpacity = useTransform(x, [-100, 0], [1, 0]);

    const handleDragEnd = (_: any, info: PanInfo) => {
      const threshold = 100;
      if (info.offset.x > threshold) {
        onSwipe("right");
      } else if (info.offset.x < -threshold) {
        onSwipe("left");
      }
    };

    return (
      <motion.div
        ref={ref}
        className="absolute w-full cursor-grab active:cursor-grabbing"
        style={{ x, rotate, opacity }}
        drag={isTop ? "x" : false}
        dragConstraints={{ left: 0, right: 0 }}
        dragElastic={0.9}
        onDragEnd={handleDragEnd}
        whileTap={{ scale: 1.02 }}
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ opacity: 0, transition: { duration: 0.2 } }}
        data-testid={`job-card-${job.id}`}
      >
        <Card className="relative overflow-visible shadow-lg border-card-border">
          {/* Like indicator */}
          <motion.div
            className="absolute top-8 right-8 z-10 rotate-12 border-4 border-green-500 rounded-md px-4 py-2"
            style={{ opacity: likeOpacity }}
          >
            <span className="text-2xl font-bold text-green-500 tracking-wider">APPLY</span>
          </motion.div>

          {/* Nope indicator */}
          <motion.div
            className="absolute top-8 left-8 z-10 -rotate-12 border-4 border-destructive rounded-md px-4 py-2"
            style={{ opacity: nopeOpacity }}
          >
            <span className="text-2xl font-bold text-destructive tracking-wider">SKIP</span>
          </motion.div>

          <CardContent className="p-6">
            {/* Header */}
            <div className="flex items-start gap-4 mb-4">
              <div className="w-16 h-16 rounded-md bg-accent flex items-center justify-center shrink-0">
                {job.logo ? (
                  <img src={job.logo} alt={job.company} className="w-12 h-12 object-contain" />
                ) : (
                  <Building2 className="w-8 h-8 text-primary" />
                )}
              </div>
              <div className="flex-1 min-w-0">
                <h2 className="text-xl font-semibold truncate" data-testid={`job-title-${job.id}`}>
                  {job.title}
                </h2>
                <p className="text-muted-foreground font-medium" data-testid={`job-company-${job.id}`}>
                  {job.company}
                </p>
              </div>
              {job.easyApply && (
                <Badge variant="secondary" className="shrink-0 gap-1">
                  <CheckCircle2 className="w-3 h-3" />
                  Easy Apply
                </Badge>
              )}
            </div>

            {/* Meta info */}
            <div className="flex flex-wrap gap-3 mb-4">
              <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
                <MapPin className="w-4 h-4" />
                <span>{job.location}</span>
              </div>
              <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
                <Briefcase className="w-4 h-4" />
                <span>{job.type}</span>
              </div>
              {job.salary && (
                <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
                  <DollarSign className="w-4 h-4" />
                  <span>{job.salary}</span>
                </div>
              )}
              <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
                <Clock className="w-4 h-4" />
                <span>{job.experience}</span>
              </div>
            </div>

            {/* Description */}
            <p className="text-sm text-muted-foreground mb-4 line-clamp-3">
              {job.description}
            </p>

            {/* Requirements */}
            <div className="mb-4">
              <h3 className="text-sm font-semibold mb-2">Requirements</h3>
              <div className="flex flex-wrap gap-2">
                {job.requirements.slice(0, 5).map((req, index) => (
                  <Badge key={index} variant="outline" className="text-xs">
                    {req}
                  </Badge>
                ))}
                {job.requirements.length > 5 && (
                  <Badge variant="outline" className="text-xs">
                    +{job.requirements.length - 5} more
                  </Badge>
                )}
              </div>
            </div>

            {/* Benefits */}
            <div>
              <h3 className="text-sm font-semibold mb-2">Benefits</h3>
              <div className="flex flex-wrap gap-2">
                {job.benefits.slice(0, 4).map((benefit, index) => (
                  <Badge key={index} className="text-xs bg-accent text-accent-foreground">
                    {benefit}
                  </Badge>
                ))}
                {job.benefits.length > 4 && (
                  <Badge className="text-xs bg-accent text-accent-foreground">
                    +{job.benefits.length - 4} more
                  </Badge>
                )}
              </div>
            </div>

            {/* Posted date */}
            <div className="mt-4 pt-4 border-t border-border">
              <p className="text-xs text-muted-foreground">
                Posted {job.postedDate}
              </p>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    );
  }
);
