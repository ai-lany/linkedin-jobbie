import { Button } from "@/components/ui/button";
import { X, RotateCcw, Heart, Zap } from "lucide-react";
import { motion } from "framer-motion";

interface SwipeActionsProps {
  onSwipeLeft: () => void;
  onSwipeRight: () => void;
  onUndo: () => void;
  onSuperLike: () => void;
  canUndo: boolean;
  disabled?: boolean;
}

export function SwipeActions({ 
  onSwipeLeft, 
  onSwipeRight, 
  onUndo, 
  onSuperLike,
  canUndo,
  disabled = false 
}: SwipeActionsProps) {
  return (
    <div className="flex items-center justify-center gap-4">
      {/* Undo button */}
      <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
        <Button
          size="icon"
          variant="outline"
          className="w-12 h-12 rounded-full"
          onClick={onUndo}
          disabled={!canUndo || disabled}
          data-testid="button-undo"
        >
          <RotateCcw className="w-5 h-5 text-muted-foreground" />
        </Button>
      </motion.div>

      {/* Skip/Nope button */}
      <motion.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}>
        <Button
          size="icon"
          variant="outline"
          className="w-16 h-16 rounded-full border-2 border-destructive"
          onClick={onSwipeLeft}
          disabled={disabled}
          data-testid="button-skip"
        >
          <X className="w-8 h-8 text-destructive" />
        </Button>
      </motion.div>

      {/* Super Apply button */}
      <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
        <Button
          size="icon"
          variant="outline"
          className="w-12 h-12 rounded-full border-2 border-blue-500"
          onClick={onSuperLike}
          disabled={disabled}
          data-testid="button-super-apply"
        >
          <Zap className="w-5 h-5 text-blue-500" />
        </Button>
      </motion.div>

      {/* Apply/Like button */}
      <motion.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}>
        <Button
          size="icon"
          className="w-16 h-16 rounded-full border-2 border-green-500 bg-green-500"
          onClick={onSwipeRight}
          disabled={disabled}
          data-testid="button-apply"
        >
          <Heart className="w-8 h-8 text-white fill-white" />
        </Button>
      </motion.div>
    </div>
  );
}
