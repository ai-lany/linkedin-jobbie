import { useState, useCallback } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { AnimatePresence, motion } from "framer-motion";
import { JobCard } from "@/components/JobCard";
import { SwipeActions } from "@/components/SwipeActions";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { Briefcase, RefreshCw, CheckCircle, TrendingUp, Sparkles } from "lucide-react";
import { queryClient, apiRequest } from "@/lib/queryClient";
import type { Job, ApplyResponse } from "@shared/schema";

export default function Home() {
  const { toast } = useToast();
  const [currentIndex, setCurrentIndex] = useState(0);
  const [swipedJobs, setSwipedJobs] = useState<Array<{ job: Job; direction: "left" | "right" }>>([]);
  const [appliedCount, setAppliedCount] = useState(0);

  const { data: jobs = [], isLoading, error, refetch } = useQuery<Job[]>({
    queryKey: ["/api/jobs"],
  });

  const applyMutation = useMutation({
    mutationFn: async (jobId: string) => {
      const response = await apiRequest("POST", "/api/apply", { jobId });
      return response.json() as Promise<ApplyResponse>;
    },
    onSuccess: (data, jobId) => {
      queryClient.invalidateQueries({ queryKey: ["/api/applications"] });
      toast({
        title: "Application Submitted",
        description: `Successfully applied to the position!`,
      });
      setAppliedCount((prev) => prev + 1);
    },
    onError: (error: any) => {
      toast({
        title: "Application Failed",
        description: error.message || "Failed to submit application",
        variant: "destructive",
      });
    },
  });

  const handleSwipe = useCallback(
    (direction: "left" | "right") => {
      if (currentIndex >= jobs.length) return;

      const currentJob = jobs[currentIndex];
      setSwipedJobs((prev) => [...prev, { job: currentJob, direction }]);
      
      if (direction === "right") {
        applyMutation.mutate(currentJob.id);
      }
      
      setCurrentIndex((prev) => prev + 1);
    },
    [currentIndex, jobs, applyMutation]
  );

  const handleUndo = useCallback(() => {
    if (swipedJobs.length === 0) return;
    
    const lastSwiped = swipedJobs[swipedJobs.length - 1];
    setSwipedJobs((prev) => prev.slice(0, -1));
    setCurrentIndex((prev) => prev - 1);
    
    if (lastSwiped.direction === "right") {
      setAppliedCount((prev) => Math.max(0, prev - 1));
    }
    
    toast({
      title: "Undone",
      description: "Previous action has been undone",
    });
  }, [swipedJobs, toast]);

  const handleSuperApply = useCallback(() => {
    if (currentIndex >= jobs.length) return;
    
    const currentJob = jobs[currentIndex];
    setSwipedJobs((prev) => [...prev, { job: currentJob, direction: "right" }]);
    applyMutation.mutate(currentJob.id);
    setCurrentIndex((prev) => prev + 1);
    
    toast({
      title: "Super Apply Sent",
      description: "Your application has been boosted!",
    });
  }, [currentIndex, jobs, applyMutation, toast]);

  const handleRefresh = () => {
    setCurrentIndex(0);
    setSwipedJobs([]);
    refetch();
  };

  const visibleJobs = jobs.slice(currentIndex, currentIndex + 3);
  const hasMoreJobs = currentIndex < jobs.length;
  const progress = jobs.length > 0 ? Math.round((currentIndex / jobs.length) * 100) : 0;

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex flex-col">
        <Header appliedCount={0} />
        <main className="flex-1 container max-w-md mx-auto px-4 py-8">
          <div className="h-[500px] relative">
            <Card className="h-full">
              <CardContent className="p-6 space-y-4">
                <div className="flex gap-4">
                  <Skeleton className="w-16 h-16 rounded-md" />
                  <div className="flex-1 space-y-2">
                    <Skeleton className="h-6 w-3/4" />
                    <Skeleton className="h-4 w-1/2" />
                  </div>
                </div>
                <div className="flex gap-2">
                  <Skeleton className="h-5 w-24" />
                  <Skeleton className="h-5 w-20" />
                  <Skeleton className="h-5 w-28" />
                </div>
                <Skeleton className="h-20 w-full" />
                <div className="space-y-2">
                  <Skeleton className="h-4 w-24" />
                  <div className="flex gap-2">
                    <Skeleton className="h-6 w-16" />
                    <Skeleton className="h-6 w-20" />
                    <Skeleton className="h-6 w-14" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-background flex flex-col">
        <Header appliedCount={0} />
        <main className="flex-1 container max-w-md mx-auto px-4 py-8 flex items-center justify-center">
          <Card className="w-full">
            <CardContent className="p-8 text-center">
              <div className="w-16 h-16 bg-destructive/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Briefcase className="w-8 h-8 text-destructive" />
              </div>
              <h2 className="text-xl font-semibold mb-2">Failed to load jobs</h2>
              <p className="text-muted-foreground mb-4">
                Something went wrong while fetching job listings
              </p>
              <Button onClick={() => refetch()} data-testid="button-retry">
                <RefreshCw className="w-4 h-4 mr-2" />
                Try Again
              </Button>
            </CardContent>
          </Card>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Header appliedCount={appliedCount} />
      
      <main className="flex-1 container max-w-md mx-auto px-4 py-6">
        {/* Progress indicator */}
        <div className="mb-4">
          <div className="flex items-center justify-between text-sm text-muted-foreground mb-2">
            <span>{currentIndex} of {jobs.length} reviewed</span>
            <span>{progress}%</span>
          </div>
          <div className="h-1.5 bg-muted rounded-full overflow-hidden">
            <motion.div 
              className="h-full bg-primary"
              initial={{ width: 0 }}
              animate={{ width: `${progress}%` }}
              transition={{ duration: 0.3 }}
            />
          </div>
        </div>

        {/* Card stack */}
        <div className="relative h-[480px] mb-6">
          <AnimatePresence mode="popLayout">
            {hasMoreJobs ? (
              visibleJobs.map((job, index) => (
                <JobCard
                  key={job.id}
                  job={job}
                  onSwipe={handleSwipe}
                  isTop={index === 0}
                />
              )).reverse()
            ) : (
              <motion.div
                key="empty"
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="absolute inset-0 flex items-center justify-center"
              >
                <Card className="w-full">
                  <CardContent className="p-8 text-center">
                    <motion.div 
                      className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4"
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      transition={{ delay: 0.2, type: "spring" }}
                    >
                      <CheckCircle className="w-10 h-10 text-primary" />
                    </motion.div>
                    <h2 className="text-xl font-semibold mb-2">All caught up!</h2>
                    <p className="text-muted-foreground mb-4">
                      You've reviewed all {jobs.length} jobs. Applied to {appliedCount} positions.
                    </p>
                    <Button onClick={handleRefresh} data-testid="button-refresh">
                      <RefreshCw className="w-4 h-4 mr-2" />
                      Start Over
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Action buttons */}
        <SwipeActions
          onSwipeLeft={() => handleSwipe("left")}
          onSwipeRight={() => handleSwipe("right")}
          onUndo={handleUndo}
          onSuperLike={handleSuperApply}
          canUndo={swipedJobs.length > 0}
          disabled={!hasMoreJobs || applyMutation.isPending}
        />

        {/* Tips */}
        <div className="mt-6 text-center">
          <p className="text-xs text-muted-foreground">
            Swipe right or tap the heart to Easy Apply
          </p>
        </div>
      </main>
    </div>
  );
}

function Header({ appliedCount }: { appliedCount: number }) {
  return (
    <header className="sticky top-0 z-50 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 border-b border-border">
      <div className="container max-w-md mx-auto px-4 h-14 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-primary rounded-md flex items-center justify-center">
            <Briefcase className="w-5 h-5 text-primary-foreground" />
          </div>
          <span className="font-semibold text-lg">JobSwipe</span>
        </div>
        
        <div className="flex items-center gap-2">
          {appliedCount > 0 && (
            <Badge variant="secondary" className="gap-1" data-testid="badge-applied-count">
              <TrendingUp className="w-3 h-3" />
              {appliedCount} Applied
            </Badge>
          )}
          <Badge className="gap-1 bg-primary text-primary-foreground">
            <Sparkles className="w-3 h-3" />
            Pro
          </Badge>
        </div>
      </div>
    </header>
  );
}
