# JobSwipe

## Overview

JobSwipe is a job discovery application that implements a Tinder-style swipe interface for browsing job opportunities. Users can swipe right to apply or left to skip job listings. The application features "Easy Apply" functionality for quick job applications with a single swipe gesture.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter (lightweight React router)
- **State Management**: TanStack React Query for server state
- **Styling**: Tailwind CSS with custom CSS variables for theming
- **UI Components**: shadcn/ui component library (Radix UI primitives)
- **Animations**: Framer Motion for swipe gestures and card animations
- **Build Tool**: Vite with React plugin

The frontend follows a component-based architecture with:
- Page components in `client/src/pages/`
- Reusable UI components in `client/src/components/ui/`
- Custom feature components in `client/src/components/`
- Shared hooks in `client/src/hooks/`

### Backend Architecture
- **Framework**: Express.js 5 with TypeScript
- **Runtime**: Node.js with tsx for TypeScript execution
- **API Design**: RESTful JSON API under `/api` prefix
- **Build**: esbuild for production bundling

Key API endpoints:
- `GET /api/jobs` - Fetch all job listings
- `GET /api/jobs/:id` - Fetch single job by ID
- `POST /api/apply` - Submit job application

### Data Storage
- **ORM**: Drizzle ORM with PostgreSQL dialect
- **Schema Location**: `shared/schema.ts`
- **Migrations**: Generated via `drizzle-kit push`
- **Current State**: In-memory storage with sample data (database schema defined but not actively used)

The storage layer uses an interface pattern (`server/storage.ts`) that can switch between in-memory and database implementations.

### Shared Code
The `shared/` directory contains:
- Database schema definitions (Drizzle tables)
- Zod validation schemas for type safety
- TypeScript types shared between frontend and backend

### Development vs Production
- **Development**: Vite dev server with HMR, served through Express middleware
- **Production**: Static files built to `dist/public`, served by Express static middleware

## External Dependencies

### Database
- **PostgreSQL**: Required for production (connection via `DATABASE_URL` environment variable)
- **Drizzle ORM**: Schema management and query building
- **connect-pg-simple**: PostgreSQL session store (available but not currently implemented)

### UI Framework
- **Radix UI**: Headless accessible component primitives
- **shadcn/ui**: Pre-styled component library built on Radix
- **Tailwind CSS**: Utility-first CSS framework

### Animation & Interaction
- **Framer Motion**: Animation library for swipe gestures
- **Embla Carousel**: Carousel functionality

### Form & Validation
- **Zod**: Schema validation
- **React Hook Form**: Form state management
- **drizzle-zod**: Zod schema generation from Drizzle tables

### Replit-Specific
- **@replit/vite-plugin-runtime-error-modal**: Error overlay for development
- **@replit/vite-plugin-cartographer**: Development tooling
- **@replit/vite-plugin-dev-banner**: Development environment indicator