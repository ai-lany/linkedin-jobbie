import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Get all jobs
  app.get("/api/jobs", async (_req, res) => {
    try {
      const jobs = await storage.getJobs();
      res.json(jobs);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch jobs" });
    }
  });

  // Get single job by ID
  app.get("/api/jobs/:id", async (req, res) => {
    try {
      const job = await storage.getJob(req.params.id);
      if (!job) {
        return res.status(404).json({ error: "Job not found" });
      }
      res.json(job);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch job" });
    }
  });

  // Easy Apply - Submit application
  app.post("/api/apply", async (req, res) => {
    try {
      const schema = z.object({
        jobId: z.string(),
      });
      
      const { jobId } = schema.parse(req.body);
      
      // Verify job exists
      const job = await storage.getJob(jobId);
      if (!job) {
        return res.status(404).json({ 
          success: false, 
          message: "Job not found" 
        });
      }

      // Check if job supports Easy Apply
      if (!job.easyApply) {
        return res.status(400).json({ 
          success: false, 
          message: "This job does not support Easy Apply" 
        });
      }

      // Create application (simulating Easy Apply API call)
      const application = await storage.createApplication(jobId);
      
      // Simulate API delay for realism
      await new Promise(resolve => setTimeout(resolve, 300));

      res.json({
        success: true,
        message: `Successfully applied to ${job.title} at ${job.company}`,
        applicationId: application.id,
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          success: false, 
          message: "Invalid request data" 
        });
      }
      res.status(500).json({ 
        success: false, 
        message: "Failed to submit application" 
      });
    }
  });

  // Get all applications
  app.get("/api/applications", async (_req, res) => {
    try {
      const applications = await storage.getApplications();
      res.json(applications);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch applications" });
    }
  });

  return httpServer;
}
