import { type User, type InsertUser, type Job, type Application } from "@shared/schema";
import { randomUUID } from "crypto";

// Sample job data for the demo
const sampleJobs: Job[] = [
  {
    id: "1",
    title: "Senior Frontend Engineer",
    company: "TechCorp Inc.",
    location: "San Francisco, CA",
    salary: "$150k - $200k",
    type: "Full-time",
    experience: "5+ years",
    description: "We are looking for a passionate Senior Frontend Engineer to join our team. You will work on building beautiful, performant user interfaces using React and TypeScript. This role offers the opportunity to lead frontend initiatives and mentor junior developers.",
    requirements: ["React", "TypeScript", "CSS-in-JS", "GraphQL", "Testing"],
    benefits: ["Health Insurance", "401k Match", "Remote Friendly", "Stock Options"],
    postedDate: "2 days ago",
    easyApply: true,
  },
  {
    id: "2",
    title: "Full Stack Developer",
    company: "StartupXYZ",
    location: "New York, NY",
    salary: "$120k - $160k",
    type: "Hybrid",
    experience: "3+ years",
    description: "Join our fast-growing startup as a Full Stack Developer. You'll work across the entire stack, from React frontend to Node.js backend, building features that impact millions of users.",
    requirements: ["Node.js", "React", "PostgreSQL", "AWS", "Docker"],
    benefits: ["Unlimited PTO", "Equity", "Learning Budget", "Team Events"],
    postedDate: "1 day ago",
    easyApply: true,
  },
  {
    id: "3",
    title: "Backend Engineer",
    company: "DataFlow Systems",
    location: "Austin, TX",
    salary: "$130k - $180k",
    type: "Remote",
    experience: "4+ years",
    description: "Looking for a Backend Engineer to design and implement scalable APIs and microservices. You'll work with cutting-edge technologies and help architect our next-generation platform.",
    requirements: ["Python", "Go", "Kubernetes", "Redis", "MongoDB"],
    benefits: ["100% Remote", "Health Benefits", "Flexible Hours", "Home Office Setup"],
    postedDate: "3 days ago",
    easyApply: true,
  },
  {
    id: "4",
    title: "Mobile Developer",
    company: "AppWorks Studio",
    location: "Seattle, WA",
    salary: "$125k - $170k",
    type: "Full-time",
    experience: "3+ years",
    description: "We're seeking a talented Mobile Developer to build cross-platform mobile applications using React Native. You'll be part of a small, agile team shipping features weekly.",
    requirements: ["React Native", "iOS", "Android", "Firebase", "Redux"],
    benefits: ["Stock Options", "Health Coverage", "Gym Membership", "Free Lunch"],
    postedDate: "5 days ago",
    easyApply: true,
  },
  {
    id: "5",
    title: "DevOps Engineer",
    company: "CloudScale Inc.",
    location: "Denver, CO",
    salary: "$140k - $190k",
    type: "Hybrid",
    experience: "4+ years",
    description: "Join our platform team as a DevOps Engineer. You'll be responsible for our CI/CD pipelines, infrastructure automation, and keeping our services running smoothly at scale.",
    requirements: ["Terraform", "AWS", "CI/CD", "Linux", "Monitoring"],
    benefits: ["Remote Work", "401k", "Education Budget", "Sabbatical"],
    postedDate: "1 week ago",
    easyApply: true,
  },
  {
    id: "6",
    title: "UX/UI Designer",
    company: "DesignHub",
    location: "Los Angeles, CA",
    salary: "$100k - $140k",
    type: "Remote",
    experience: "2+ years",
    description: "We're looking for a creative UX/UI Designer to craft beautiful and intuitive user experiences. You'll work closely with product and engineering teams to bring ideas to life.",
    requirements: ["Figma", "Prototyping", "User Research", "Design Systems", "Accessibility"],
    benefits: ["Creative Freedom", "Health Insurance", "Conference Budget", "Flexible PTO"],
    postedDate: "4 days ago",
    easyApply: true,
  },
  {
    id: "7",
    title: "Data Scientist",
    company: "AI Innovations",
    location: "Boston, MA",
    salary: "$145k - $195k",
    type: "Full-time",
    experience: "4+ years",
    description: "Join our AI team to build machine learning models that power our products. You'll work on challenging problems in NLP, computer vision, and predictive analytics.",
    requirements: ["Python", "TensorFlow", "PyTorch", "SQL", "Statistics"],
    benefits: ["Research Time", "GPU Access", "Conference Travel", "Stock Options"],
    postedDate: "6 days ago",
    easyApply: true,
  },
  {
    id: "8",
    title: "Product Manager",
    company: "ProductFirst",
    location: "Chicago, IL",
    salary: "$135k - $175k",
    type: "Hybrid",
    experience: "5+ years",
    description: "Lead product strategy and development for our B2B SaaS platform. You'll work with cross-functional teams to define roadmaps and deliver features that delight customers.",
    requirements: ["Roadmapping", "Analytics", "Stakeholder Management", "Agile", "User Research"],
    benefits: ["Leadership Role", "Equity", "Health Benefits", "Remote Options"],
    postedDate: "3 days ago",
    easyApply: true,
  },
];

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getJobs(): Promise<Job[]>;
  getJob(id: string): Promise<Job | undefined>;
  createApplication(jobId: string): Promise<Application>;
  getApplications(): Promise<Application[]>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private jobs: Map<string, Job>;
  private applications: Map<string, Application>;

  constructor() {
    this.users = new Map();
    this.jobs = new Map();
    this.applications = new Map();
    
    // Initialize with sample jobs
    sampleJobs.forEach(job => {
      this.jobs.set(job.id, job);
    });
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getJobs(): Promise<Job[]> {
    return Array.from(this.jobs.values());
  }

  async getJob(id: string): Promise<Job | undefined> {
    return this.jobs.get(id);
  }

  async createApplication(jobId: string): Promise<Application> {
    const id = randomUUID();
    const application: Application = {
      id,
      jobId,
      status: "applied",
      appliedAt: new Date().toISOString(),
    };
    this.applications.set(id, application);
    return application;
  }

  async getApplications(): Promise<Application[]> {
    return Array.from(this.applications.values());
  }
}

export const storage = new MemStorage();
