import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Job listing schema
export const jobSchema = z.object({
  id: z.string(),
  title: z.string(),
  company: z.string(),
  location: z.string(),
  salary: z.string().optional(),
  type: z.enum(["Full-time", "Part-time", "Contract", "Remote", "Hybrid"]),
  experience: z.string(),
  description: z.string(),
  requirements: z.array(z.string()),
  benefits: z.array(z.string()),
  postedDate: z.string(),
  logo: z.string().optional(),
  easyApply: z.boolean(),
});

export type Job = z.infer<typeof jobSchema>;

// Application schema
export const applicationSchema = z.object({
  id: z.string(),
  jobId: z.string(),
  status: z.enum(["applied", "rejected"]),
  appliedAt: z.string(),
});

export type Application = z.infer<typeof applicationSchema>;

// API response types
export const applyResponseSchema = z.object({
  success: z.boolean(),
  message: z.string(),
  applicationId: z.string().optional(),
});

export type ApplyResponse = z.infer<typeof applyResponseSchema>;
